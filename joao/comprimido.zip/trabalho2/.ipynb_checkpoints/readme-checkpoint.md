# Forecast usando dados meteorologicos

Metodologia: Utilizar Cross Correlation pra encontrar os parametros do VAR e construir o modelo.

https://machinelearningmastery.com/how-to-use-the-timeseriesgenerator-for-time-series-forecasting-in-keras/